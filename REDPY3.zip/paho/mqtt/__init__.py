__version__ = "1.3.1"


class MQTTException(Exception):
    pass
